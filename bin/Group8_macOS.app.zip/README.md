# Puzzl3Blocks
Group 8

##########
For the mac version you must add the game using sudo chmod -R 755

example "sudo chmod -R 755 /Users/rfueston/Downloads/MacBuild\ 5.app"

after that open the app, dismiss the error, and you have to go to security settings to open the app from there since the developer is not trusted.

any mac troubleshooting question please feel free to email me at rfueston@students.kennesaw.edu
##########
